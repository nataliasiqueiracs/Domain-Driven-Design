package br.com.nataliascigliano.model.vo;

/**
 * 
 * @author User
 * @see Classe que cria objeto capaz de armazenar os dados relativos ao processo de ordena��o
 *@version 0.1 - 21/9/2023
 *
 *Model
 *VO - Value Object
 */


public class Ordenacao {
	
	//atributos
	private int numeroOriginal;
	private String numeroOrdenado;
	private int qtdeTrocas;
	
	/**
	 * Construtor parametrizado que inicializa os atributos da classe
	 * @param numeroOriginal
	 * @param numeroOrdenado
	 * @param qtdeTrocas
	 */
	public Ordenacao(int numeroOriginal, String numeroOrdenado, int qtdeTrocas) {
		this.numeroOriginal = numeroOriginal;
		this.numeroOrdenado = numeroOrdenado;
		this.qtdeTrocas = qtdeTrocas;
	}

	/**
	 * @return the numeroOriginal
	 */
	public int getNumeroOriginal() {
		return numeroOriginal;
	}

	/**
	 * @param numeroOriginal the numeroOriginal to set
	 */
	public void setNumeroOriginal(int numeroOriginal) {
		this.numeroOriginal = numeroOriginal;
	}

	/**
	 * @return the numeroOrdenado
	 */
	public String getNumeroOrdenado() {
		return numeroOrdenado;
	}

	/**
	 * @param numeroOrdenado the numeroOrdenado to set
	 */
	public void setNumeroOrdenado(String numeroOrdenado) {
		this.numeroOrdenado = numeroOrdenado;
	}

	/**
	 * @return the qtdeTrocas
	 */
	public int getQtdeTrocas() {
		return qtdeTrocas;
	}

	/**
	 * @param qtdeTrocas the qtdeTrocas to set
	 */
	public void setQtdeTrocas(int qtdeTrocas) {
		this.qtdeTrocas = qtdeTrocas;
	}
	
	//Sobescrevendo o m�todo toString de Object
	public String toString() {
		//casting de int para String
		return String.valueOf(this.getNumeroOriginal()).concat(" virou: \n").concat(String.valueOf(this.getNumeroOrdenado()))
				.concat(" Qtd de trocas: ").concat(String.valueOf(getQtdeTrocas()));
	}
	
}
