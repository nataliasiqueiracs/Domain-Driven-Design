package br.com.nataliascigliano.model.vo;

/**
 * 
 * @author User
 * Aqui � uma forma de documentar o c�digo de uma forma profissional.
 * @see Classe que armazena os dados relativos a cada passo da ordena��o
 * @version 0.1 - 21/9/2023
 * 
 * VO = Value Object (� de valor porque � ele que guarda os dados de um objeto)
 * 
 */

public class Passos {

	//atributos
	private String numeroAnterior;
	private String numeroResultante;
	private String descricao;
	
	/**
	 * Construtor que preenche os atributos do objeto
	 * @param numeroAnterior - descri��o: .....
	 * @param numeroResultante
	 * @param descricao
	 */
	public Passos(String numeroAnterior, String numeroResultante,
			String descricao) {
		this.numeroAnterior = numeroAnterior;
		this.numeroResultante = numeroResultante;
		this.descricao = descricao;
	}

	/**
	 * @return the numeroAnterior
	 */
	public String getNumeroAnterior() {
		return numeroAnterior;
	}

	/**
	 * @param numeroAnterior the numeroAnterior to set
	 */
	public void setNumeroAnterior(String numeroAnterior) {
		this.numeroAnterior = numeroAnterior;
	}

	/**
	 * @return the numeroResultante
	 */
	public String getNumeroResultante() {
		return numeroResultante;
	}

	/**
	 * @param numeroResultante the numeroResultante to set
	 */
	public void setNumeroResultante(String numeroResultante) {
		this.numeroResultante = numeroResultante;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		if(this.getNumeroAnterior() == null) {
			return "\nDescri��o: ".concat(getDescricao());
		}else {
			return this.getNumeroAnterior().concat(" >> ").concat(getNumeroAnterior()).concat("\nDescri��o: ").concat(getDescricao()).concat("\n\n");
		}
	}
	
	
	
	
	
}
