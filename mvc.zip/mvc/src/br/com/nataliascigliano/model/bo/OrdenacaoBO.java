package br.com.nataliascigliano.model.bo;

import java.util.ArrayList;
import java.util.List;

import br.com.nataliascigliano.model.dao.OrdenacaoDAO;
import br.com.nataliascigliano.model.dao.PassosDAO;
import br.com.nataliascigliano.model.vo.Ordenacao;
import br.com.nataliascigliano.model.vo.Passos;

public class OrdenacaoBO {
	
	/**
	 * @see M�todo respons�vel em fazer a ordena��o atrav�s do algoritmo Bubble Sort (m�todo bolha)
	 * @param numero
	 * @return Ordenacao
	 */
	
	public Ordenacao bubbleSort(int numero) {
		
		//array de char, chamado d�gitos
		//vai converter para array de texto, depois mudar para array de char... para facilitar a separa��o
		//toCharArray = transforma o n�mero em string para fazer as trocas considerando caracter por caracter
		char[] digitos = String.valueOf(numero).toCharArray();
		
		//vari�vel auxiliar (intermediar entre as trocas)
		char aux;
		
		//outra vari�vel auxiliar para armazenar o n�mero antes da modifica��o
		char[] antes;
		
		//vari�vel que ser� incrementada a cada troca realizada
		//contar quantas trocas ocorreram
		int qtdeTrocas = 0;
		
		//vetor/array/lista de passos para descrever todo o processo
		List<Passos> passos = new ArrayList<Passos>();
		
		/**
		 * Vari�vel que determina se houve troca
		 * ser� usada para interromper o processo quando j� n�o houver mais n�meros a serem ordenados
		 */
		boolean continua = true;
		
		for(int i=0; i<digitos.length;i++) {
			//verifica se foram feitas trocas no �ltimo ciclo
			//se n�o, indica que o n�mero j� est� ordenado
			if(!continua){
				break;
			}
			//descrever o passo a cada rodada do la�o de repeti��o
			passos.add(new Passos(null, null, "In�cio da verifica��o".concat(String.valueOf(i)).concat("\n-----------------------------\n")));
			
			continua = false;
			
			//Percorrendo cada n�mero com o seu pr�ximo
			for(int j=0; j<digitos.length - 1; j++) {
				if (digitos[j] > digitos[j+1]) {
					//O n�mero � maior do que o pr�ximo -> troca!
					
					antes = new String(digitos).toCharArray();
					
					aux = digitos[j];
					digitos[j] = digitos[j+1];
					digitos[j+1] = aux;
					
					//incrementando a quantidade de trocas
					qtdeTrocas++;
					
					//Descrevendo o passo
					passos.add(new Passos(new String(antes), new String(digitos), "Trocou-se o d�gito ".concat(String.valueOf(digitos[j+1]))
							.concat("pelo ".concat(digitos[j]))));
					
					
					continua = true;
					
				}else {
					passos.add(new Passos(new String(digitos), new String(digitos), "N�o houve troca, pois o n�mero "
							.concat(String.valueOf(digitos[j]))
							.concat(" � menor ou igual � " 
							.concat(String.valueOf(digitos[j+1])))));
				}
			}
			
		}
		
		//Persiste os resultados
		Ordenacao ordenacao = new Ordenacao(numero, new String(digitos), qtdeTrocas);
		new OrdenacaoDAO().salvar(ordenacao);
		new PassosDAO().salvarPassos(passos);
		
		return Ordenacao;
		
	}
	
}
