package br.com.nataliascigliano.model.dao;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 * @see Classe que executa as oera��es de IO (entrada e sa�da) dos dados com rela��o aos dados resultantes da ordena��o.
 * @author User
 *
 */

public class OrdenacaoDAO {
	public void salvar(Ordenacao ordenacao) {
		
		try {
			PrintWriter pw = new PrintWriter("ordenacao.txt");
			pw.print(ordenacao);
			pw.flush();
			pw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
	}
	
	
	
}
