package br.com.nataliascigliano.model.dao;

import java.io.FileNotFoundException;

import java.io.PrintWriter;


import br.com.nataliascigliano.model.vo.Ordenacao;
/**
 * @see Classe que executa as oera��es de IO (entrada e sa�da) dos dados com rela��o aos dados resultantes da ordena��o.
 * @author User
 *
 */

public class OrdenacaoDAO {
	public void salvar(Ordenacao ordenacao) throws FileNotFoundException {
		PrintWriter pw = new PrintWriter("ordenacao.txt");
		pw.print(ordenacao);
		pw.flush(); //limpar o buffer
		pw.close(); // fecha o arquivo
	}
}
	
	
	
