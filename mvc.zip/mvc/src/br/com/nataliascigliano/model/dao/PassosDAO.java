package br.com.nataliascigliano.model.dao;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

import br.com.nataliascigliano.model.vo.Passos;
import java.io.PrintWriter;
import java.util.List;

import br.com.nataliascigliano.model.vo.Passos;
/**
* 
* @author User
* @see Classe que executa as opera��es de IO (entrada e sa�da) do sistema com rela��o aos dados resultantes do passo a passo.
*
*/


public class PassosDAO {
	
	/**
	 * M�todo salvarPassos recebe uma lista (passos), ir� percorrer a lista e salvar todos os passos em um arquivo de texto.
	 * @param passos
	 * @throws FileNotFoundException
	 */
	
	public void salvarPassos(List<Passos> passos){
		PrintWriter pw;
		try {
			pw = new PrintWriter("passos.txt");
			for (Passos p : passos) {
				pw.print(p);
			}
			
			pw.flush();
			pw.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
}
