package br.com.nataliascigliano.model.dao;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

import br.com.nataliascigliano.model.vo.Passos;

/**
* 
* @author User
* @see Classe que executa as opera��es de IO (entrada e sa�da) do sistema com rela��o aos dados resultantes do passo a passo.
*
*/


public class PassosDAO {
	
	/**
	 * M�todo salvarPassos recebe uma lista (passos), ir� percorrer a lista e salvar todos os passos em um arquivo de texto.
	 * @param passos
	 * @throws FileNotFoundException
	 */
	
	public void salvarPassos(List<Passos> passos) throws FileNotFoundException {
		PrintWriter pw = new PrintWriter("passos.txt");
		
		for (Passos p : passos) {
			pw.print(p);
		}
		
		//o flush limpa o buffer para tirar a 'sujeira'
		pw.flush();
		pw.close();
	}
	
	
}
